import torch
import torch.nn as nn

from feedguard.util import add_dp_noise


class EmbeddingNet(nn.Module):
    def __init__(self, state_dim, action_dim, embed_dim, max_ep_len, noise_multiplier=None):
        super(EmbeddingNet, self).__init__()
        self.embed_dim = embed_dim
        self.noise_multiplier = noise_multiplier

        self.embed_rtg = nn.Linear(1, embed_dim)
        self.embed_state = nn.Linear(state_dim, embed_dim)
        self.embed_action = nn.Linear(action_dim, embed_dim)
        self.embed_timestep = nn.Embedding(max_ep_len, embed_dim)
        self.embed_ln = nn.LayerNorm(embed_dim)

    def forward(self, rtgs, states, actions, timesteps, attention_mask=None):
        """
        :param rtgs: batch_size x timesteps_len x 1
        :param states: batch_size x timesteps_len x state_dim
        :param actions: batch_size x timesteps_len x 1
        :param timesteps: batch_size x timesteps_len
        :return:
        """
        batch_size, seq_length, _ = rtgs.shape

        # 输入数据检查
        assert seq_length == states.shape[1] == timesteps.shape[1]
        if actions is None:
            assert seq_length == 1
        else:
            assert actions.shape[1] == seq_length or actions.shape[1] == (seq_length - 1)

        if attention_mask is None:
            attention_mask = torch.ones((batch_size, seq_length), dtype=torch.long).to(rtgs.device)
        else:
            assert attention_mask.shape[1] == seq_length

        # 1. embed each modality with a different head
        state_embeddings = self.embed_state(states)  # [b,s,e]
        action_embeddings = self.embed_action(actions) if actions is not None else None # [b,s,e]
        rtg_embeddings = self.embed_rtg(rtgs)  # [b,s,e]
        pos_embeddings = self.embed_timestep(timesteps)  # [b,s,e]

        # 2. time embeddings are treated similar to positional embeddings
        state_embeddings = state_embeddings + pos_embeddings
        action_embeddings = (action_embeddings + pos_embeddings[:,:action_embeddings.shape[1]]) if action_embeddings is not None else None
        returns_embeddings = rtg_embeddings + pos_embeddings

        # 3. stack all embedding: (R_1, s_1, a_1, R_2, s_2, a_2, ...)
        if actions is not None and actions.shape[1] == seq_length:
            stacked_inputs = torch.stack(
                (returns_embeddings, state_embeddings, action_embeddings), dim=1
            ).permute(0, 2, 1, 3).reshape(batch_size, 3 * seq_length, self.embed_dim)  # [b,3*s,e]
        else:
            if actions is None:
                stacked_inputs = torch.cat([returns_embeddings, state_embeddings], dim=1) # [b,2,e]
            else:
                stacked_inputs = torch.stack(
                    (returns_embeddings[:,:-1], state_embeddings[:,:-1], action_embeddings), dim=1
                ).permute(0, 2, 1, 3).reshape(batch_size, -1, self.embed_dim)  # [b,3*(s-1),e]
                stacked_inputs = torch.cat([stacked_inputs, returns_embeddings[:,-1:], state_embeddings[:,-1:]], dim=1)
        stacked_inputs = self.embed_ln(stacked_inputs)

        # to make the attention mask fit the stacked inputs, have to stack it as well
        stacked_attention_mask = torch.stack(
            (attention_mask, attention_mask, attention_mask), dim=1
        ).permute(0, 2, 1).reshape(batch_size, 3 * seq_length)
        if actions is None or actions.shape[1] == (seq_length - 1):
            stacked_attention_mask = stacked_attention_mask[:, :-1]

        if self.noise_multiplier:
            stacked_inputs = add_dp_noise(stacked_inputs, self.noise_multiplier)
        return stacked_inputs, stacked_attention_mask


class PredictHead(nn.Module):
    def __init__(self, hidden_dim, action_dim):
        super(PredictHead, self).__init__()
        self.predict_action = nn.Sequential(
            nn.Linear(hidden_dim, action_dim),
            nn.Tanh()
        )

    def forward(self, h):
        """
        :param h: batch_size x 3*seq_len x hidden_dim
        :return:
        """
        action_preds_h = h[:, 1::3]  # [b,(R1,S1,A1,R2,S2),e]
        action_preds = self.predict_action(action_preds_h)  # predict next action given state last hidden embedding
        return action_preds
