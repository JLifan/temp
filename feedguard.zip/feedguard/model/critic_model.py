import math

import torch
import torch.nn as nn
import numpy as np

from feedguard.util import add_dp_noise


class CriticEmbeddingNet(nn.Module):
    def __init__(self, state_dim, action_dim, embed_dim, max_ep_len, noise_multiplier=None):
        super(CriticEmbeddingNet, self).__init__()
        self.embed_dim = embed_dim
        self.noise_multiplier = noise_multiplier

        self.embed_state = nn.Linear(state_dim, embed_dim)
        self.embed_action = nn.Linear(action_dim, embed_dim)
        self.embed_timestep = nn.Embedding(max_ep_len, embed_dim)
        self.embed_ln = nn.LayerNorm(embed_dim)


    def forward(self, states, actions, timesteps, attention_mask=None):
        """
        :param states: batch_size x timesteps_len x state_dim
        :param actions: batch_size x timesteps_len x 1
        :param timesteps: batch_size x timesteps_len
        :return:
        """
        batch_size, seq_length, _ = states.shape

        # 输入数据检查
        assert seq_length == actions.shape[1] == timesteps.shape[1]
        if attention_mask is None:
            attention_mask = torch.ones((batch_size, seq_length), dtype=torch.long).to(states.device)

        # 1. embed each modality with a different head
        state_embeddings = self.embed_state(states)  # [b,s,e]
        action_embeddings = self.embed_action(actions) # [b,s,e]
        pos_embeddings = self.embed_timestep(timesteps)  # [b,s,e]

        # 2. time embeddings are treated similar to positional embeddings
        state_embeddings = state_embeddings + pos_embeddings
        action_embeddings = action_embeddings + pos_embeddings

        # 3. stack all embedding: (s_1, a_1, s_2, a_2, ...)
        stacked_inputs = torch.stack(
            (state_embeddings, action_embeddings), dim=1
        ).permute(0, 2, 1, 3).reshape(batch_size, 2 * seq_length, self.embed_dim)  # [b,2*s,e]
        stacked_inputs = self.embed_ln(stacked_inputs)

        # to make the attention mask fit the stacked inputs, have to stack it as well
        stacked_attention_mask = torch.stack(
            (attention_mask, attention_mask), dim=1
        ).permute(0, 2, 1).reshape(batch_size, 2 * seq_length)

        if self.noise_multiplier:
            stacked_inputs = add_dp_noise(stacked_inputs, self.noise_multiplier)
        return stacked_inputs, stacked_attention_mask


class Gaussian:
    """ Represents a gaussian distribution """
    def __init__(self, mu, log_sigma=None):
        """

        :param mu:
        :param log_sigma: If none, mu is divided into two chunks, mu and log_sigma
        """
        if log_sigma is None:
            if not isinstance(mu, torch.Tensor):
                import pdb; pdb.set_trace()
            mu, log_sigma = torch.chunk(mu, 2, -1)

        self.mu = mu
        self.log_sigma = torch.clamp(log_sigma, min=-10, max=2) if isinstance(log_sigma, torch.Tensor) else \
                            np.clip(log_sigma, a_min=-10, a_max=2)
        self._sigma = None

    @staticmethod
    def ten2ar(tensor):
        if isinstance(tensor, np.ndarray):
            return tensor
        elif torch.is_tensor(tensor):
            return tensor.detach().cpu().numpy()
        elif np.isscalar(tensor):
            return tensor
        elif hasattr(tensor, 'to_numpy'):
            return tensor.to_numpy()
        else:
            import pdb; pdb.set_trace()
            raise ValueError('input to ten2ar cannot be converted to numpy array')

    def sample(self):
        return self.mu + self.sigma * torch.randn_like(self.sigma)

    def kl_divergence(self, other):
        """Here self=q and other=p and we compute KL(q, p)"""
        return (other.log_sigma - self.log_sigma) + (self.sigma ** 2 + (self.mu - other.mu) ** 2) \
               / (2 * other.sigma ** 2) - 0.5

    def nll(self, x):
        # Negative log likelihood (probability)
        return -1 * self.log_prob(x)

    def log_prob(self, val):
        """Computes the log-probability of a value under the Gaussian distribution."""
        return -1 * ((val - self.mu) ** 2) / (2 * self.sigma**2) - self.log_sigma - math.log(math.sqrt(2*math.pi))

    def entropy(self):
        return 0.5 + 0.5 * math.log(2 * math.pi) + torch.log(self.sigma)

    @property
    def sigma(self):
        if self._sigma is None:
            self._sigma = self.log_sigma.exp()
        return self._sigma

    @property
    def shape(self):
        return self.mu.shape

    @staticmethod
    def stack(*argv, dim):
        return Gaussian._combine(torch.stack, *argv, dim=dim)

    @staticmethod
    def cat(*argv, dim):
        return Gaussian._combine(torch.cat, *argv, dim=dim)

    @staticmethod
    def _combine(fcn, *argv, dim):
        mu, log_sigma = [], []
        for g in argv:
            mu.append(g.mu)
            log_sigma.append(g.log_sigma)
        mu = fcn(mu, dim)
        log_sigma = fcn(log_sigma, dim)
        return Gaussian(mu, log_sigma)

    def average(self, dists):
        """Fits single Gaussian to a list of Gaussians."""
        mu_avg = torch.stack([d.mu for d in dists]).sum(0) / len(dists)
        sigma_avg = torch.stack([d.mu ** 2 + d.sigma ** 2 for d in dists]).sum(0) - mu_avg**2
        return type(self)(mu_avg, torch.log(sigma_avg))

    def chunk(self, *args, **kwargs):
        return [type(self)(chunk) for chunk in torch.chunk(self.tensor(), *args, **kwargs)]

    def view(self, shape):
        self.mu = self.mu.view(shape)
        self.log_sigma = self.log_sigma.view(shape)
        self._sigma = self.sigma.view(shape)
        return self

    def __getitem__(self, item):
        return Gaussian(self.mu[item], self.log_sigma[item])

    def tensor(self):
        return torch.cat([self.mu, self.log_sigma], dim=-1)

    def rsample(self):
        """Identical to self.sample(), to conform with pytorch naming scheme."""
        return self.sample()

    def detach(self):
        """Detaches internal variables. Returns detached Gaussian."""
        return type(self)(self.mu.detach(), self.log_sigma.detach())

    def to_numpy(self):
        """Convert internal variables to numpy arrays."""
        return type(self)(self.ten2ar(self.mu), self.ten2ar(self.log_sigma))

class MultivariateGaussian(Gaussian):
    def log_prob(self, val):
        return super().log_prob(val).sum(-1)

    @staticmethod
    def stack(*argv, dim):
        return MultivariateGaussian(Gaussian.stack(*argv, dim=dim).tensor())

    @staticmethod
    def cat(*argv, dim):
        return MultivariateGaussian(Gaussian.cat(*argv, dim=dim).tensor())

class CriticPredictHead(nn.Module):
    def __init__(self, hidden_dim, z_dim=1):
        super().__init__()

        self.mu = nn.Linear(hidden_dim, z_dim)
        self.log_std = nn.Linear(hidden_dim, z_dim)

        def _weight_init(m):
            """Custom weight init for Conv2D and Linear layers."""
            if isinstance(m, torch.nn.Linear):
                nn.init.orthogonal_(m.weight.data)
                if hasattr(m.bias, "data"):
                    m.bias.data.fill_(0.0)

        self.apply(_weight_init)

    def forward(self, h):
        """
        :param h: batch_size x 2*seq_len x hidden_dim
        :return:
        """
        x = h[:, 1::2]  # [b,(S1,A1,S2,A2),e]

        mu = self.mu(x)
        log_std = self.log_std(x)

        return MultivariateGaussian(mu, log_std) # [b,s,1]


