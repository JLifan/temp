import os

import torch

from feedguard.model.server_model import ServerModel


class ComputeServer:
    def __init__(self, decision_model_embed_dim=128, decision_model_num_layers=3, decision_model_num_heads=2,
                 critic_model_embed_dim=128, critic_model_num_layers=3, critic_model_num_heads=2,
                 decision_lr=1e-4, decision_w_decay=1e-4, critic_lr=1e-4, critic_w_decay=1e-4, device="cuda"):
        self.device = device

        self.model = ServerModel(decision_model_embed_dim, decision_model_num_layers, decision_model_num_heads).to(self.device)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=decision_lr, weight_decay=decision_w_decay)

        self.critic_model = ServerModel(critic_model_embed_dim, critic_model_num_layers, critic_model_num_heads).to(self.device)
        self.critic_optimizer = torch.optim.Adam(self.critic_model.parameters(),
                                                 lr=critic_lr, weight_decay=critic_w_decay)

    def forward(self, stacked_inputs, stacked_attention_mask):
        return self.model(stacked_inputs, stacked_attention_mask)

    def save_decision_model(self, path):
        os.makedirs(path, exist_ok=True)
        torch.save(self.model.state_dict(), os.path.join(path, "server_transform.pth"))

    def save_critic_model(self, path):
        os.makedirs(path, exist_ok=True)
        torch.save(self.critic_model.state_dict(), os.path.join(path, "server_critic.pth"))

    def save_model(self, path):
        self.save_decision_model(path)
        self.save_critic_model(path)

    def load_decision_model(self, path):
        self.model.load_state_dict(torch.load(os.path.join(path, "server_transform.pth")))

    def load_critic_model(self, path):
        self.critic_model.load_state_dict(torch.load(os.path.join(path, "server_critic.pth")))

    def load_model(self, path):
        self.load_decision_model(path)
        self.load_critic_model(path)

    def enable_train(self):
        self.model.train()
        self.critic_model.train()

        self.optimizer.zero_grad()
        self.critic_optimizer.zero_grad()


    def update_server(self):
        decision_model_update = False
        for param in self.model.parameters():
            if param.grad is not None:
                decision_model_update = True
                break
        if decision_model_update:
            self.optimizer.step()
            print("[INFO] Updated server models related to decision.")

        critic_model_update = False
        for param in self.critic_model.parameters():
            if param.grad is not None:
                critic_model_update = True
                break
        if critic_model_update:
            self.critic_optimizer.step()
            print("[INFO] Updated server models related to critic.")
