import copy

class FedServer:
    def __init__(self, clients, eta_decision_model=0.01, eta_critic_model=0.01):
        self.clients = clients

        self.global_client_parameters = {
            "embedding_net": clients[0].get_parameters("embedding_net"),
            "predict_head": clients[0].get_parameters("predict_head"),
            "critic_embedding_net": clients[0].get_parameters("critic_embedding_net"),
            "critic_predict_head": clients[0].get_parameters("critic_predict_head"),
        }

        self.eta_decision_model = eta_decision_model
        self.eta_critic_model = eta_critic_model

    def synchronous_aggregate(self, net_name, sample_num_list, target_client_ids:list=None):
        if target_client_ids:
            all_params = [self.clients[c].get_parameters(net_name) for c in target_client_ids]
        else:
            all_params = [c.get_parameters(net_name) for c in self.clients]

        total_sample_num = sum(sample_num_list)
        avg_params = copy.deepcopy(all_params[0])
        avg_params = {k: v * (sample_num_list[0] / total_sample_num) for k, v in avg_params.items()}
        for k in avg_params:
            for i in range(len(all_params)):
                avg_params[k] += all_params[i][k] * (sample_num_list[i] / total_sample_num)

        for client in self.clients:
            client.set_parameters(net_name, avg_params)
        print(f"[INFO] Aggregated {net_name} and distributed to all clients.")

        self.global_client_parameters[net_name] = avg_params

    def asynchronous_aggregate(self, net_name, client_id):
        eta = self.eta_critic_model if "critic" in net_name else self.eta_decision_model

        original_params = self.global_client_parameters[net_name]
        new_params = self.clients[client_id].get_parameters(net_name)
        for k in new_params:
            new_params[k] = (1-eta) * original_params[k] + eta * new_params[k]

        self.global_client_parameters[net_name] = new_params

    def get_global_client_parameters(self, net_name):
        return self.global_client_parameters[net_name]