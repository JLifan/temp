# Offline pre-training of decision models
python scripts/run_offline_train.py

# Offline pre-training of critic models
python scripts/run_critic_train.py

# Online evaluation and fine-tuning
python scripts/run_online_finetuning.py