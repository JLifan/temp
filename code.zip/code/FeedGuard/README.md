# FeedGuard - Submission Reproducibility Instructions

This repository contains the code to reproduce the main experimental results submission:


---


## Environment Setup

We recommend using **Python 3.9**.

Install dependencies:
```bash
pip install -r requirements.txt
```




## Project Structure
```
FeedGuard/
├── data/                   # Data that you need to manually download
├── feedguard/              # Core algorithm code (client, server, models)
├── virtual_taobao/         # Simulated environment
├── scripts/                # Main experiment entry points
├── run_all.sh              # One-click reproduction script
├── requirements.txt        # Python dependencies
└── README.md               # This file
```




## Simulated Environment: VirtualTaobao

FeedGuard experiments are conducted in the **VirtualTaobao simulator**, which emulates a large-scale e-commerce recommendation environment.

All required pretrained simulation components are included under the `virtual_taobao/` directory.

> **Note:** The files in `virtual_taobao/data/` are **not experimental datasets**.  
> Instead, they are pretrained models used to construct the simulation environment. These models serve as components of the RL-based proxy for user behavior and are not the input/output data used by the FeedGuard algorithm.

### Components Overview

- `action_model.pt`: simulates action selection within the environment.
- `generator_model.pt`: generate user state features during interactions.
- `leave_model.pt`: simulates user dropout behavior (i.e., whether a user leaves the platform).


### License and Attribution of VirtualTaobao
- Source: [https://github.com/eyounx/VirtualTaobao](https://github.com/eyounx/VirtualTaobao)
- Description: This project provides VirtualTaobao simulators trained from the real-data of Taobao, one of the largest online retail platforms. 
- License: MIT License
- Citation: Jing-Cheng Shi, Yang Yu, Qing Da, Shi-Yong Chen, and An-Xiang Zeng. Virtual-Taobao: Virtualizing real-world online retail environment for reinforcement learning. In: Proceedings of the 33rd AAAI Conference on Artificial Intelligence (AAAI’19), Honolulu, HI, 2019.



## Dataset Description

Due to size limitations of supplementary materials, the full dataset is hosted externally on Zenodo via an anonymized, publicly accessible link. 

You can obtain the datasets by visit the [download link](https://zenodo.org/records/15486881?preview=1&token=eyJhbGciOiJIUzUxMiJ9.eyJpZCI6Ijg3YTU4ZWE5LTBlOTEtNDU2NS1iYjFhLTFkMGIzZjRkMTA5NiIsImRhdGEiOnt9LCJyYW5kb20iOiIyNjQ4NTZkMTllNDNiZTZiMzRkM2Y1M2JlYmE2MGJhZSJ9.hnAR8D93ex8iC0lquNonlNQhS3wOTolPpn545x31ozvF3ZNXFi_HwjkUXm3vrcZFmUh5SXV_a-mcAM3rENBRKw), download and extract the archive `FeedGuard_data.zip` manually, then place the entire extracted folder under the `FeedGuard/` directory.



The dataset includes:

- `offline_data/`: This folder contains personalized interaction trajectories for 1000 users (clients). Each user has 1000 trajectories, and each user's data is stored in a separate file (e.g., `0.pt`, `1.pt`, ..., `999.pt`). These trajectories are collected from expert policies interacting within the VirtualTaobao simulator and serve as the offline training data for the federated learning process.

- `test_user.pt`: This file contains representation features for another batch of 1000 randomly sampled users. It is used during evaluation to simulate new users outside the training pool, ensuring the generalization of the trained models.

All files are in PyTorch `.pt` format and are automatically loaded by the training and evaluation scripts.




## Running Experiments
Run all major experiments with one script:

```bash
bash run_all.sh
```
This includes:
- Offline pre-training of decision models
- Offline pre-training of critic models
- Online evaluation and fine-tuning

Individual experiments can also be run as follows:

```bash
# Offline pre-training of decision models
python scripts/run_offline_train.py

# Offline pre-training of critic models
python scripts/run_critic_train.py

# Online evaluation and fine-tuning
python scripts/run_online_finetuning.py
```