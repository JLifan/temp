import torch.nn as nn

from transformers import GPT2Config, GPT2Model

class ServerModel(nn.Module):
    def __init__(self, embed_dim, n_layer, n_head, **kwargs):
        super(ServerModel, self).__init__()
        self.embed_dim = embed_dim

        config = GPT2Config(
            vocab_size=1,  # doesn't matter -- we don't use the vocab
            n_embd=embed_dim,
            n_layer=n_layer,
            n_head=n_head,
            **kwargs
        )
        self.transformer = GPT2Model(config)

    def forward(self, stacked_inputs, stacked_attention_mask):
        transformer_outputs = self.transformer(
            inputs_embeds=stacked_inputs,
            attention_mask=stacked_attention_mask,
        )
        x = transformer_outputs['last_hidden_state']  # [b,3*s,e]
        return x
