import os
import gc
import copy
from contextlib import contextmanager

import torch
import torch.optim as optim
from opacus import GradSampleModule
from opacus.optimizers import DPOptimizer

from feedguard.client.buffer import TrajectoryReplayBuffer
from feedguard.model.client_model import EmbeddingNet, PredictHead
from feedguard.model.critic_model import CriticEmbeddingNet, CriticPredictHead
from feedguard.util import masked_mse_loss, safe_clear_grad_sample, get_model_device, masked_critic_loss, \
    estimate_action_entropy_from_embeddings


class Client:
    def __init__(self, state_dim, action_dim, decision_model_embed_dim=128, critic_model_embed_dim=128,
                 max_ep_len=100000, noise_multiplier=1.0, max_grad_norm=1.0,
                 decision_lr=1e-3, decision_w_decay=0, critic_lr=1e-3, critic_w_decay=0,
                 lambda_entropy=0.01, lambda_critic_loss=0.01,
                 replay_buffer_capacity=1000, device="cpu"):
        self.noise_multiplier = noise_multiplier
        self.max_grad_norm = max_grad_norm
        self.lambda_entropy = lambda_entropy
        self.lambda_critic_loss = lambda_critic_loss

        # initial net
        self.embedding_net = EmbeddingNet(state_dim, action_dim, decision_model_embed_dim,
                                          max_ep_len, noise_multiplier).to(device)
        self.predict_head = PredictHead(decision_model_embed_dim, action_dim).to(device)

        self.critic_embedding_net = CriticEmbeddingNet(state_dim, action_dim, critic_model_embed_dim,
                                                       max_ep_len, noise_multiplier).to(device)
        self.critic_predict_head = CriticPredictHead(critic_model_embed_dim).to(device)

        # initial opt
        self.optimizer_emb = optim.Adam(self.embedding_net.parameters(), lr=decision_lr, weight_decay=decision_w_decay)
        self.optimizer_head = optim.Adam(self.predict_head.parameters(), lr=decision_lr, weight_decay=decision_w_decay)

        self.optimizer_critic_emb = optim.Adam(self.critic_embedding_net.parameters(),
                                               lr=critic_lr, weight_decay=critic_w_decay)
        self.optimizer_critic_head = optim.Adam(self.critic_predict_head.parameters(),
                                                lr=critic_lr, weight_decay=critic_w_decay)

        # buffer
        self.replay_buffer = TrajectoryReplayBuffer(capacity=replay_buffer_capacity)


    def to_device(self, device):
        self.embedding_net = self.embedding_net.to(device)
        self.predict_head = self.predict_head.to(device)

        self.critic_embedding_net = self.critic_embedding_net.to(device)
        self.critic_predict_head = self.critic_predict_head.to(device)

        if device == "cpu":
            gc.collect()
            torch.cuda.empty_cache()


    @contextmanager
    def fed_train(self, dp=True, expected_batch_size=128, device="cuda",
                  train_decision_net=True, train_critic_net=True, entropy=True):
        assert train_decision_net or train_critic_net, "请选择train的对象"
        self.train_decision_net = train_decision_net
        self.train_critic_net = train_critic_net
        self.entropy = entropy

        self._enable_fed_train(dp, expected_batch_size, device)
        yield
        self._disable_fed_train(dp)

    def _enable_fed_train(self, dp=True, expected_batch_size=128, device="cuda"):
        print("[INFO] Enabling federated training mode...")

        def _copy_model_and_optimizer(model_raw, optimizers_raw):
            model_new = copy.deepcopy(model_raw).to(device)
            if dp:
                model_new = GradSampleModule(model_new)

            optimizers_new = optim.Adam(model_new.parameters())
            optimizers_new.load_state_dict(optimizers_raw.state_dict())
            if dp:
                optimizers_new = DPOptimizer(optimizer=optimizers_new,
                                             noise_multiplier=self.noise_multiplier,
                                             max_grad_norm=self.max_grad_norm,
                                             expected_batch_size=expected_batch_size)
            return model_new, optimizers_new


        # ===== copy net related to decision for federated train =====
        if self.train_decision_net:
            self.embedding_net_, self.optimizer_emb_ = _copy_model_and_optimizer(self.embedding_net, self.optimizer_emb)
            self.predict_head_, self.optimizer_head_ = _copy_model_and_optimizer(self.predict_head, self.optimizer_head)

        # ===== copy net related to critic for federated train =====
        if self.train_critic_net:
            self.critic_embedding_net_, self.optimizer_critic_emb_ = _copy_model_and_optimizer(self.critic_embedding_net,
                                                                                               self.optimizer_critic_emb)
            self.critic_predict_head_, self.optimizer_critic_head_ = _copy_model_and_optimizer(self.critic_predict_head,
                                                                                               self.optimizer_critic_head)

    def _disable_fed_train(self, dp=True):
        def _load_model_and_optimizer(model_raw, optimizers_raw, model_target_name, optimizers_target_name):
            model_para = model_raw._module.state_dict() if dp else model_raw.state_dict()

            model_para = {k: p.to(get_model_device(getattr(self, model_target_name))) for k, p in model_para.items()}
            getattr(self, model_target_name).load_state_dict(model_para)

            getattr(self, optimizers_target_name).load_state_dict(optimizers_raw.state_dict())

        def _del_model_and_optimizer(model_name, optimizers_name):
            safe_clear_grad_sample(getattr(self, model_name))
            getattr(self, model_name).to("cpu")

            delattr(self, model_name)
            delattr(self, optimizers_name)

        # ===== decision net  =====
        if self.train_decision_net:
            _load_model_and_optimizer(self.embedding_net_, self.optimizer_emb_,
                                      "embedding_net", "optimizer_emb")
            _del_model_and_optimizer("embedding_net_", "optimizer_emb_")

            _load_model_and_optimizer(self.predict_head_, self.optimizer_head_,
                                      "predict_head", "optimizer_head")
            _del_model_and_optimizer("predict_head_", "optimizer_head_")

        # ===== critic net  =====
        if self.train_critic_net:
            _load_model_and_optimizer(self.critic_embedding_net_, self.optimizer_critic_emb_,
                                      "critic_embedding_net", "optimizer_critic_emb")
            _del_model_and_optimizer("critic_embedding_net_", "optimizer_critic_emb_")

            _load_model_and_optimizer(self.critic_predict_head_, self.optimizer_critic_head_,
                                      "critic_predict_head", "optimizer_critic_head")
            _del_model_and_optimizer("critic_predict_head_", "optimizer_critic_head_")


        gc.collect()
        torch.cuda.empty_cache()

        print("[INFO] Disabling federated training mode...")


    def get_parameters(self, net_name):
        net = getattr(self, net_name)
        return {k: v.clone().cpu() for k, v in net.state_dict().items()}

    def set_parameters(self, net_name, param_dict):
        net = getattr(self, net_name)
        net.load_state_dict(param_dict)

    def fetch_global_client_params_from_fed_server(self, fed_server):
        self.set_parameters("embedding_net", fed_server.get_global_client_parameters("embedding_net"))
        self.set_parameters("predict_head", fed_server.get_global_client_parameters("predict_head"))
        self.set_parameters("critic_embedding_net", fed_server.get_global_client_parameters("critic_embedding_net"))
        self.set_parameters("critic_predict_head", fed_server.get_global_client_parameters("critic_predict_head"))

    def inference_step(self, compute_server, rtgs, states, actions, timesteps, attention_mask=None):
        # === move model to gpu ===
        self.embedding_net.eval()
        compute_server.model.eval()
        self.predict_head.eval()

        with torch.no_grad():
            stacked_inputs, stacked_attention_mask = self.embedding_net(rtgs, states, actions, timesteps, attention_mask)
            transformer_out = compute_server.model(stacked_inputs, stacked_attention_mask)
            action_preds = self.predict_head(transformer_out)

        return action_preds


    def train_step(self, compute_server, rtgs, states, actions, timesteps, attention_mask, targets):
        # ===== 1. fetch model and optimizer =====
        # decision model
        embedding_net = getattr(self, 'embedding_net_', self.embedding_net)
        predict_head = getattr(self, 'predict_head_', self.predict_head)

        optimizer_emb = getattr(self, 'optimizer_emb_', self.optimizer_emb)
        optimizer_head = getattr(self, 'optimizer_head_', self.optimizer_head)

        # critic model
        critic_embedding_net = getattr(self, 'critic_embedding_net_', self.critic_embedding_net)
        critic_predict_head = getattr(self, 'critic_predict_head_', self.critic_predict_head)

        optimizer_critic_emb = getattr(self, 'optimizer_critic_emb_', self.optimizer_critic_emb)
        optimizer_critic_head = getattr(self, 'optimizer_critic_head_', self.optimizer_critic_head)

        # ===== 2. move input tensors to device =====
        device = get_model_device(embedding_net) if self.train_decision_net else get_model_device(critic_embedding_net)

        rtgs, states, actions, timesteps = rtgs.to(device), states.to(device), actions.to(device), timesteps.to(device)
        targets = targets.to(device)
        attention_mask = attention_mask.to(device) if attention_mask is not None else None

        # ===== 3. training =====
        loss_decision, loss_critic, traj_entropy = 0, 0, 0
        action_preds = None
        compute_server.enable_train()
        if self.train_decision_net:
            embedding_net.train()
            predict_head.train()

            optimizer_emb.zero_grad()
            optimizer_head.zero_grad()

            # 1. Forward
            stacked_inputs, stacked_attention_mask = embedding_net(rtgs, states, actions, timesteps, attention_mask)
            decision_out = compute_server.model(stacked_inputs, stacked_attention_mask)
            action_preds = predict_head(decision_out)

            # 2. Backward
            loss_decision = masked_mse_loss(action_preds, targets, attention_mask)

            if self.entropy:
                traj_entropy = estimate_action_entropy_from_embeddings(action_preds, mask=attention_mask)

        if self.train_critic_net:
            critic_embedding_net.train()
            critic_predict_head.train()

            optimizer_critic_emb.zero_grad()
            optimizer_critic_head.zero_grad()

            stacked_inputs, stacked_attention_mask = critic_embedding_net(states,
                                                                          action_preds if action_preds is not None else actions,
                                                                          timesteps, attention_mask)
            critic_out = compute_server.critic_model(stacked_inputs, stacked_attention_mask)
            return_preds = critic_predict_head(critic_out)
            loss_critic = masked_critic_loss(return_preds, rtgs, attention_mask)

        loss = loss_decision - self.lambda_entropy * traj_entropy + self.lambda_critic_loss * loss_critic
        loss.backward()

        # 4. update
        compute_server.update_server()

        if self.train_critic_net:
            optimizer_critic_head.step()
            optimizer_critic_emb.step()

        if self.train_decision_net:
            optimizer_head.step()
            optimizer_emb.step()
        return loss.item()

    def save_decision_model(self, path):
        os.makedirs(path, exist_ok=True)
        torch.save(self.embedding_net.state_dict(), os.path.join(path, "embedding_net.pth"))
        torch.save(self.predict_head.state_dict(), os.path.join(path, "predict_head.pth"))

    def save_critic_model(self, path):
        os.makedirs(path, exist_ok=True)
        torch.save(self.critic_embedding_net.state_dict(), os.path.join(path, "critic_embedding_net.pth"))
        torch.save(self.critic_predict_head.state_dict(), os.path.join(path, "critic_predict_head.pth"))

    def save_model(self, path):
        self.save_decision_model(path)
        self.save_critic_model(path)

    def load_decision_model(self, path):
        self.embedding_net.load_state_dict(torch.load(os.path.join(path, "embedding_net.pth")))
        self.predict_head.load_state_dict(torch.load(os.path.join(path, "predict_head.pth")))

    def load_critic_model(self, path):
        self.critic_embedding_net.load_state_dict(torch.load(os.path.join(path, "critic_embedding_net.pth")))
        self.critic_predict_head.load_state_dict(torch.load(os.path.join(path, "critic_predict_head.pth")))

    def load_model(self, path):
        self.load_decision_model(path)
        self.load_critic_model(path)