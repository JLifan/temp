import torch
from torch.utils.data import Dataset

def collate_fn(batch):
    max_len = max(item['states'].shape[0] for item in batch)

    def pad_seq(seq, pad_shape):
        pad_len = max_len - seq.shape[0]
        return torch.cat([seq, torch.zeros(pad_len, *pad_shape)], dim=0)

    rtgs = torch.stack([pad_seq(item['rtgs'], (1,)) for item in batch])
    states = torch.stack([pad_seq(item['states'], (batch[0]['states'].shape[1],)) for item in batch])
    actions = torch.stack([pad_seq(item['actions'], (batch[0]['actions'].shape[1],)) for item in batch])
    timesteps = torch.stack([pad_seq(item['timesteps'], ()).long() for item in batch])
    targets = torch.stack([pad_seq(item['targets'], (batch[0]['targets'].shape[1],)) for item in batch])

    attention_mask = torch.stack([
        torch.cat([torch.ones(item['states'].shape[0]), torch.zeros(max_len - item['states'].shape[0])])
        for item in batch
    ]).to(torch.long)

    return {
        "rtgs": rtgs,
        "states": states,
        "actions": actions,
        "timesteps": timesteps,
        "targets": targets,
        "attention_mask": attention_mask
    }


class TrajectoryDataset(Dataset):
    def __init__(self, pt_file_path):
        super().__init__()
        self.trajectories = torch.load(pt_file_path)  # list of trajectories

    def __len__(self):
        return len(self.trajectories)

    def __getitem__(self, idx):
        traj_dict = self.trajectories[idx]
        return {
            "rtgs": torch.flip(torch.cumsum(torch.flip(traj_dict["rewards"], dims=[0]), dim=0), dims=[0]).unsqueeze(-1),
            "states": traj_dict["states"],
            "actions": traj_dict["actions"],
            "timesteps": traj_dict["timesteps"] - 1,
            "targets": traj_dict["actions"].clone()
        }