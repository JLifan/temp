import copy
import random
from collections import namedtuple

import torch


Trajectory = namedtuple(
    'Trajectory', ('rtgs', 'states', 'actions', 'timesteps'))

class TrajectoryReplayBuffer(object):
    def __init__(self, capacity):
        self.capacity = capacity

        self.buffer = []
        self.position = 0

    def push(self, *args):
        """Saves a trajectory."""
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = Trajectory(*args)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        max_len = max(item[0].shape[1] for item in batch)

        def pad_seq(seq, pad_dim=1):
            pad_len = max_len - seq.shape[pad_dim]
            shape = list(seq.shape)
            shape[pad_dim] = pad_len
            return torch.cat([seq, torch.zeros(shape)], dim=pad_dim)

        rtgs = torch.cat([pad_seq(item[0]) for item in batch], dim=0)
        states = torch.cat([pad_seq(item[1]) for item in batch], dim=0)
        actions = torch.cat([pad_seq(item[2]) for item in batch], dim=0)
        timesteps = torch.cat([pad_seq(item[3]).long() for item in batch], dim=0)
        targets = copy.deepcopy(actions)

        attention_mask = torch.stack([
            torch.cat([torch.ones(item[0].shape[0]), torch.zeros(max_len - item[0].shape[0])])
            for item in batch
        ]).to(torch.long)

        return {
            "rtgs": rtgs,
            "states": states,
            "actions": actions,
            "timesteps": timesteps,
            "targets": targets,
            "attention_mask": attention_mask
        }

    def __len__(self):
        return len(self.buffer)