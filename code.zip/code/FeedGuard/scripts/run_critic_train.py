import os
import sys
import copy
import json
import random
import argparse

PARENT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(PARENT_DIR)
sys.path.append(PARENT_DIR + "/feedguard")
sys.path.append(PARENT_DIR + "/scripts")

import gym
from gym.envs.registration import register
register(
    id='VirtualTB-v0',
    entry_point='virtual_taobao.envs:VirtualTB',
)

import numpy as np
import torch

from feedguard.client import Client, TrajectoryDataset, collate_fn
from feedguard.server import FedServer, ComputeServer
from scripts.run_offline_train import args_check_and_process


def create_envs(args):
    ### Environment setting
    env = gym.make('VirtualTB-v0')
    if args.seed:
        env.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)

    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]

    ###  Initialize clients
    client = Client(state_dim, action_dim, critic_model_embed_dim=args.embed_dim, max_ep_len=args.max_ep_len,
                    critic_lr=args.learning_rate_client_critic, critic_w_decay=args.weight_decay_client_critic,
                    noise_multiplier=args.noise_multiplier, max_grad_norm=args.max_grad_norm)
    clients = [copy.deepcopy(client) for _ in range(args.client_num)]
    print(f"[INFO] Initialized {len(clients)} Clients.")

    ###  Initialize server
    compute_server = ComputeServer(critic_model_embed_dim=args.embed_dim, critic_model_num_layers=args.num_layers,
                                   critic_model_num_heads=args.num_heads, critic_lr=args.learning_rate_server_critic,
                                   critic_w_decay=args.weight_decay_server_critic, device="cuda")
    fed_server = FedServer(clients)
    print("[INFO] Initialized ComputeServer and FedServer.")

    return clients, fed_server, compute_server


def federal_learning_critic_model(args, clients, fed_server, compute_server):
    for epoch_idx in range(args.epochs):
        print(f"\n==========================")
        print(f"[INFO][Epoch {epoch_idx}] Starting...")

        selected_clients = random.sample(range(args.client_num), int(args.client_sample_rate * args.client_num))
        sample_num_list = []

        for idx in selected_clients:
            dataset = TrajectoryDataset(os.path.join(args.offline_dataset_dir, f"{idx}.pt"))
            expected_batch_size = int(len(dataset) * args.data_sample_rate)
            sample_num_list.append(expected_batch_size)

            indices = random.sample(range(len(dataset)), expected_batch_size)
            batch = collate_fn([dataset[i] for i in indices])

            client = clients[idx]
            with client.fed_train(dp=True, expected_batch_size=expected_batch_size, device="cuda",
                                  train_decision_net=False, train_critic_net=True, entropy=False):
                loss = client.train_step(compute_server, **batch)
                print(f"[INFO][Epoch {epoch_idx}] Trained Client {idx} with Loss: {loss:.4f}")

        fed_server.synchronous_aggregate("embedding_net", sample_num_list, selected_clients)
        fed_server.synchronous_aggregate("predict_head", sample_num_list, selected_clients)

        print(f"[INFO][Epoch {epoch_idx}] Finished.")
        print(f"==========================")

    print("[INFO] Training complete.")

def run(args):
    print(f"[INFO] Start the critic model pre-training...")
    print(f"[INFO] Args: {args}")

    args = args_check_and_process(args)
    clients, fed_server, compute_server = create_envs(args)
    federal_learning_critic_model(args, clients, fed_server, compute_server)

    with open(f"{args.model_save_dir}/critic_model_pretrain_args.json", "w") as f:
        json.dump(vars(args), f, indent=4)
    print(f"[INFO] Saved critic model pre-training args in {args.model_save_dir}.")

    clients[0].save_critic_model(args.model_save_dir)
    compute_server.save_critic_model(args.model_save_dir)
    print(f"[INFO] Saved args and trained critic model in client and server in {args.model_save_dir}.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', type=str, default='TB')
    parser.add_argument('--seed', type=int, default=None)
    parser.add_argument('--offline_dataset_dir', type=str, default=f"{PARENT_DIR}/data/offline_data/")
    parser.add_argument('--client_num', type=int, default=1000)
    parser.add_argument('--max_ep_len', type=int, default=100000)
    parser.add_argument('--learning_rate_server_critic', type=float, default=1e-3)
    parser.add_argument('--weight_decay_server_critic', type=float, default=0)
    parser.add_argument('--learning_rate_client_critic', type=float, default=1e-3)
    parser.add_argument('--weight_decay_client_critic', type=float, default=0)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--data_sample_rate', type=float, default=0.1)
    parser.add_argument('--client_sample_rate', type=float, default=0.1)
    parser.add_argument('--noise_multiplier', type=float, default=1.0)
    parser.add_argument('--max_grad_norm', type=float, default=1.0)
    parser.add_argument('--delta', type=float, default=1e-5)
    parser.add_argument('--target_epsilon', type=float, default=None)
    parser.add_argument('--embed_dim', type=int, default=128)
    parser.add_argument('--num_layers', type=int, default=3)
    parser.add_argument('--num_heads', type=int, default=2)

    args = parser.parse_args()
    run(args)