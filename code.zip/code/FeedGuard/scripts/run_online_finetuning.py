import os
import sys
import json
import copy
import random
import argparse

PARENT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.append(PARENT_DIR)
sys.path.append(PARENT_DIR + "/feedguard")


import gym
from gym.envs.registration import register
register(
    id='VirtualTB-v0',
    entry_point='virtual_taobao.envs:VirtualTB',
)

import numpy as np
import torch
from opacus.accountants.utils import get_noise_multiplier

from feedguard.client import Client
from feedguard.server import FedServer, ComputeServer


def args_check_and_process(args):
    assert args.test_client_path is not None
    if not os.path.exists(args.test_client_path):
        assert IOError(
            "Cannot find the dataset. Please download the dataset according to the instructions in README.md.")

    args.target_return = args.target_return / args.scale

    if args.target_epsilon is not None:
        sample_client_num = int(args.client_sample_rate * args.client_num)
        args.noise_multiplier = get_noise_multiplier(target_epsilon=args.target_epsilon / sample_client_num,
                                             target_delta=args.delta,
                                             sample_rate =  args.data_sample_rate * args.client_sample_rate,
                                             steps = 6 * 50, accountant="rdp")
        print(f"[INFO] To achieve ε = {args.target_epsilon}, the noise_multiplier σ ≈ {args.noise_multiplier:.3f}")

    args.model_dir = os.path.join(PARENT_DIR, "model")
    if os.path.exists(os.path.join(args.model_dir, "decision_model_pretrain_args.json")):
        with open(f"{args.model_dir}/decision_model_pretrain_args.json", "r") as f:
            decision_model_args_dict = json.load(f)
            args.decision_model_embed_dim = decision_model_args_dict["embed_dim"]
            args.decision_model_num_layers = decision_model_args_dict["num_layers"]
            args.decision_model_num_heads = decision_model_args_dict["num_heads"]
    if os.path.exists(os.path.join(args.model_dir, "critic_model_pretrain_args.json")):
        with open(f"{args.model_dir}/critic_model_pretrain_args.json", "r") as f:
            critic_model_args_dict = json.load(f)
            args.critic_model_embed_dim = critic_model_args_dict["embed_dim"]
            args.critic_model_num_layers = critic_model_args_dict["num_layers"]
            args.critic_model_num_heads = critic_model_args_dict["num_heads"]

    return args


def create_envs(args):
    ### Environment setting
    env = gym.make('VirtualTB-v0')
    if args.seed:
        env.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)

    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]

    ###  Initialize clients
    client = Client(state_dim, action_dim,
                    decision_model_embed_dim=args.decision_model_embed_dim,
                    critic_model_embed_dim=args.critic_model_embed_dim,
                    decision_lr=args.learning_rate_client_decision, decision_w_decay=args.weight_decay_client_decision,
                    critic_lr=args.learning_rate_client_critic, critic_w_decay=args.weight_decay_client_critic,
                    noise_multiplier=args.noise_multiplier, max_grad_norm=args.max_grad_norm,
                    replay_buffer_capacity=args.replay_buffer_capacity,
                    lambda_entropy=args.lambda_entropy,
                    lambda_critic_loss=args.lambda_critic_loss)

    if os.path.exists(os.path.join(args.model_dir, "embedding_net.pth")) and \
            os.path.exists(os.path.join(args.model_dir, "predict_head.pth")):
        client.load_decision_model(args.model_dir)
        print("[INFO] Loaded decision model in Client.")
    if os.path.exists(os.path.join(args.model_dir, "critic_embedding_net.pth")) and \
            os.path.exists(os.path.join(args.model_dir, "critic_predict_head.pth")):
        client.load_critic_model(args.model_dir)
        print("[INFO] Loaded critic model in Client.")

    clients = [copy.deepcopy(client) for _ in range(args.client_num)]
    print(f"[INFO] Initialized {len(clients)} Clients.")

    ###  Initialize server
    fed_server = FedServer(clients)
    compute_server = ComputeServer(decision_model_embed_dim=args.decision_model_embed_dim,
                                   decision_model_num_layers=args.decision_model_num_layers,
                                   decision_model_num_heads=args.decision_model_num_heads,
                                   critic_model_embed_dim=args.critic_model_embed_dim,
                                   critic_model_num_layers=args.critic_model_num_layers,
                                   critic_model_num_heads=args.critic_model_num_heads,
                                   decision_lr=args.learning_rate_server_decision,
                                   decision_w_decay=args.weight_decay_server_decision,
                                   critic_lr=args.learning_rate_server_critic,
                                   critic_w_decay=args.weight_decay_server_critic,
                                   device="cuda")

    if os.path.exists(os.path.join(args.model_dir, "server_transform.pth")):
        compute_server.load_decision_model(args.model_dir)
        print("[INFO] Loaded decision model in Server.")
    if os.path.exists(os.path.join(args.model_dir, "server_critic.pth")):
        compute_server.load_critic_model(args.model_dir)
        print("[INFO] Loaded critic model in Server.")

    print("[INFO] Initialized ComputeServer and FedServer.")

    return env, clients, fed_server, compute_server


def online_test_and_learning(args, env, clients, fed_server, compute_server):
    test_clients = torch.load(args.test_client_path)

    episode_reward, episode_step = 0, 0
    for i_episode in range(args.episodes):
        # for idx in selected_clients:
        idx = random.sample(range(args.client_num), 1)[0]
        client = clients[idx]
        client.to_device("cuda")
        client.fetch_global_client_params_from_fed_server(fed_server)

        # ===== Inference =====
        timestep = 0
        env.reset()

        rtgs = torch.tensor(args.target_return).reshape(1, 1, 1).cuda()  # [b=1,s=1,1]
        states = torch.Tensor([env.reset_z(test_clients[idx])]).unsqueeze(dim=1).cuda() # [b=1,s=1,state_dim]
        timesteps = torch.tensor(timestep).reshape(1, 1).cuda()  # [b=1,s=1]
        actions = None
        rewards = None

        while True:
            action = client.inference_step(compute_server, rtgs, states, actions, timesteps)[:,-1:]
            actions = action if actions is None else torch.cat([actions, action], dim=1)

            action = action[0, -1].detach().cpu().numpy()
            next_state, reward, done, info = env.step(action)
            episode_reward += reward
            episode_step += 1

            rewards = torch.ones([1,1,1]).cuda() * reward if rewards is None \
                else torch.cat([rewards, torch.ones([1,1,1]).cuda() * reward], dim=1)

            if done:
                relable_rtgs = torch.flip(torch.cumsum(torch.flip(rewards, dims=[0]), dim=1), dims=[1])
                clients[idx].replay_buffer.push(relable_rtgs.to("cpu"), states.to("cpu"), actions.to("cpu"), timesteps.to("cpu"))
                break

            next_state = torch.from_numpy(next_state).reshape(1, 1, -1).to(torch.float32).cuda()
            states = torch.cat([states, next_state], dim=1)

            next_rtg = rtgs[:, -1:] - reward / args.scale
            rtgs = torch.cat([rtgs, next_rtg], dim=1)

            timesteps = torch.cat([timesteps, torch.ones((1, 1), dtype=torch.long).cuda() * (timestep + 1)], dim=1)
            timestep = timestep + 1

        client.to_device("cpu")
        print(f"[INFO][Episode {i_episode}][Decision episode_reward: {episode_reward:.4f}")

        # ===== Fine-tuning =====
        expected_batch_size = int(client.replay_buffer.capacity * args.data_sample_rate)
        if len(client.replay_buffer) >= expected_batch_size:
            batch = client.replay_buffer.sample(expected_batch_size)
            with client.fed_train(dp=True, expected_batch_size=expected_batch_size, device="cuda",
                                  train_decision_net=True, train_critic_net=True, entropy=True):
                loss = client.train_step(compute_server, **batch)
                print(f"[INFO][Episode {i_episode}] Trained Client {idx} with Loss: {loss:.4f}")

            fed_server.asynchronous_aggregate("embedding_net", idx)
            fed_server.asynchronous_aggregate("predict_head", idx)
            fed_server.asynchronous_aggregate("critic_embedding_net", idx)
            fed_server.asynchronous_aggregate("critic_predict_head", idx)
            print(f"[INFO][Episode {i_episode}] Asynchronous aggregate the global client model")

        if i_episode % args.eval_interaction_num == (args.eval_interaction_num - 1):
            ctr = episode_reward / episode_step / 10
            print(f"[Result][Episode {i_episode - args.eval_interaction_num + 1}] CTR: {ctr}")
            episode_reward, episode_step = 0, 0

    print("[INFO] Online test and fine-tuning completed.")


def run(args):
    print(f"[INFO] Start the online test and fine-tuning...")
    print(args)

    args = args_check_and_process(args)
    env, clients, fed_server, compute_server = create_envs(args)
    online_test_and_learning(args, env, clients, fed_server, compute_server)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', type=str, default='TB')
    parser.add_argument('--seed', type=int, default=None)
    parser.add_argument('--test_client_path', type=str, default=f"{PARENT_DIR}/data/test_user.pt")
    parser.add_argument('--client_num', type=int, default=1000)
    parser.add_argument('--replay_buffer_capacity', type=int, default=1000)
    parser.add_argument('--learning_rate_server_decision', type=float, default=1e-4)
    parser.add_argument('--weight_decay_server_decision', type=float, default=0)
    parser.add_argument('--learning_rate_server_critic', type=float, default=1e-4)
    parser.add_argument('--weight_decay_server_critic', type=float, default=0)
    parser.add_argument('--learning_rate_client_decision', type=float, default=1e-4)
    parser.add_argument('--weight_decay_client_decision', type=float, default=0)
    parser.add_argument('--learning_rate_client_critic', type=float, default=1e-4)
    parser.add_argument('--weight_decay_client_critic', type=float, default=0)
    parser.add_argument('--lambda_entropy', type=float, default=0.01)
    parser.add_argument('--lambda_critic_loss', type=float, default=0.01)
    parser.add_argument('--episodes', type=int, default=100000)
    parser.add_argument('--eval_interaction_num', type=int, default=50)
    parser.add_argument('--client_sample_rate', type=float, default=0.1)
    parser.add_argument('--data_sample_rate', type=float, default=0.1)
    parser.add_argument('--noise_multiplier', type=float, default=1.0)
    parser.add_argument('--max_grad_norm', type=float, default=1.0)
    parser.add_argument('--delta', type=float, default=1e-5)
    parser.add_argument('--target_epsilon', type=int, default=None)
    parser.add_argument('--target_epsilon_stage', type=int, default=None)
    parser.add_argument('--decision_model_embed_dim', type=int, default=128)
    parser.add_argument('--decision_model_num_layers', type=int, default=6)
    parser.add_argument('--decision_model_num_heads', type=int, default=8)
    parser.add_argument('--critic_model_embed_dim', type=int, default=128)
    parser.add_argument('--critic_model_num_layers', type=int, default=3)
    parser.add_argument('--critic_model_num_heads', type=int, default=2)
    parser.add_argument('--target_return', type=int, default=6000)
    parser.add_argument('--scale', type=int, default=10)

    args = parser.parse_args()
    run(args)
